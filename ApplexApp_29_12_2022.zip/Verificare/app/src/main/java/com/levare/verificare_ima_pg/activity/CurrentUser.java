package com.levare.verificare_ima_pg.activity;

import com.levare.verificare_ima_pg.model.User;

public class CurrentUser {

    private User user;

    private static CurrentUser mCurrentUser;

    private CurrentUser() {

    }

    public static CurrentUser getInstance() {
        if (mCurrentUser == null) {
            synchronized (CurrentUser.class) {
                mCurrentUser = new CurrentUser();
            }
        }
        return mCurrentUser;
    }

    public User getUser() {
        return user;
    }

    public void setCurrentUser(User mUser) {
        this.user = mUser;
    }
}
