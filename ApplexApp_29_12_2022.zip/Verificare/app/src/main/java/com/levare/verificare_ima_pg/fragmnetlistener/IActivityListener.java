package com.levare.verificare_ima_pg.fragmnetlistener;

import com.levare.verificare_ima_pg.model.BatchDetail;

public interface IActivityListener {
    void getBatchDetails(BatchDetail batchDetail);
}
