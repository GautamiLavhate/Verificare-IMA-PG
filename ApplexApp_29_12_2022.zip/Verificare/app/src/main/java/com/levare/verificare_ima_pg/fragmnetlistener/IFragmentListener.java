package com.levare.verificare_ima_pg.fragmnetlistener;

import com.levare.verificare_ima_pg.model.BatchDetail;

public interface IFragmentListener {

    void sendBatchDetails(BatchDetail batchDetail);
}
