package com.levare.verificare_ima_pg.network;

public class Constant {

    public static Boolean isLocation=false,isSubLocation=false;
    public static Boolean isAddLocation=false,isAddSubLocation=false;
    public static Boolean scan=false;

    //public static String Base_url="https://applexinfotech.com/fav/";
    public static String Base_url="https://verificare-imapg.levare.co.in/";

}
